$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$py = '.\.venv\Scripts\python.exe'
if (!(Test-Path $py)) {
    throw 'The .venv was not found. Copy this script into the project root containing .venv and requirements.txt.'
}

Write-Host 'Installing missing Click dependency...' -ForegroundColor Cyan
& $py -m pip install --no-cache-dir 'click==8.1.8'
if ($LASTEXITCODE -ne 0) { throw 'Click installation failed.' }

$requirements = Join-Path $PSScriptRoot 'requirements.txt'
if (!(Test-Path $requirements)) { throw 'requirements.txt was not found.' }
$content = Get-Content $requirements
if (-not ($content -match '^click==')) {
    @('click==8.1.8') + $content | Set-Content $requirements -Encoding utf8
}

$setup = Join-Path $PSScriptRoot 'setup_windows.ps1'
if (Test-Path $setup) {
    $text = Get-Content $setup -Raw
    $old = '--only-binary=:all: numpy==2.0.2 thinc==8.3.6 spacy==3.8.7'
    $new = '--only-binary=:all: numpy==2.0.2 thinc==8.3.6 spacy==3.8.7 click==8.1.8'
    $text = $text.Replace($old, $new)
    $text | Set-Content $setup -Encoding utf8
}

Write-Host 'Verifying native NLP imports...' -ForegroundColor Cyan
& $py -c "import click,numpy,thinc,spacy; print('Click',click.__version__); print('NumPy',numpy.__version__); print('Thinc',thinc.__version__); print('spaCy',spacy.__version__); print('NLP IMPORT PASS')"
if ($LASTEXITCODE -ne 0) { throw 'NLP imports still fail.' }

Write-Host 'Installing the complete project requirements...' -ForegroundColor Cyan
& $py -m pip install --no-cache-dir -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Application dependency installation failed.' }

Write-Host 'Installing the spaCy English model...' -ForegroundColor Cyan
& $py -m spacy download en_core_web_sm
if ($LASTEXITCODE -ne 0) { throw 'spaCy model installation failed.' }

Write-Host 'Verifying spaCy and Presidio...' -ForegroundColor Cyan
& $py -c "import spacy; nlp=spacy.load('en_core_web_sm'); from presidio_analyzer import AnalyzerEngine; AnalyzerEngine(); print('spaCy model and Presidio PASS')"
if ($LASTEXITCODE -ne 0) { throw 'spaCy model or Presidio initialization failed.' }

& $py -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Broken dependencies detected.' }

& $py -m pytest -q
if ($LASTEXITCODE -ne 0) { throw 'Automated tests failed.' }

Write-Host 'SETUP RESUMED SUCCESSFULLY. Configure .env and run start_windows.ps1.' -ForegroundColor Green
