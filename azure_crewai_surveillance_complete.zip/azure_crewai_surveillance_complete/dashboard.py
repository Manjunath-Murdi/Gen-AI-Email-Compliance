import os,json,httpx,streamlit as st
st.set_page_config(page_title='Azure CrewAI Surveillance',layout='wide');st.title('Azure CrewAI Communication Surveillance')
API=st.sidebar.text_input('API URL',os.getenv('API_URL','http://127.0.0.1:8000')).rstrip('/');key=st.sidebar.text_input('Admin key',type='password');page=st.sidebar.radio('Page',['Analyze','Alerts','Matrix','Policies'])
def get(p):r=httpx.get(API+p,timeout=20);r.raise_for_status();return r.json()
try:h=get('/health');st.sidebar.success(f"Connected | LLM {'ON' if h['llm_enabled'] else 'OFF'} | PII {h['pii_engine']} | RAG {h['rag']['chunks']}")
except Exception as e:st.sidebar.error(f'Backend unavailable: {e}')
if page=='Analyze':
    with st.form('mail'):
        a,b=st.columns(2);mid=a.text_input('Message ID','mail-1001');sender=a.text_input('Sender','employee@bank.com');rec=a.text_input('Recipients','broker@external.com');subject=a.text_input('Subject','Closing price');body=b.text_area('Email','Please keep this between us.\nCan we push the closing price today?\nDelete this email after reading.\nContact John Smith at john@example.com.',height=180);go=st.form_submit_button('Analyze',type='primary')
    if go:
        r=httpx.post(API+'/analyze',json={'message_id':mid,'sender':sender,'recipients':[x.strip() for x in rec.split(',') if x.strip()],'subject':subject,'body':body},timeout=240);r.raise_for_status();st.session_state.r=r.json()
    if 'r' in st.session_state:
        r=st.session_state.r;c=st.columns(5);c[0].metric('Flagged','YES' if r['flagged'] else 'NO');c[1].metric('Priority',r['priority'].upper());c[2].metric('Risk',r['risk_score']);c[3].metric('PII',len(r['pii_entities']));c[4].metric('Policies',len(r['retrieved_policies']))
        if r['guardrail_flags']:st.warning(', '.join(r['guardrail_flags']))
        with st.expander('Masked email'):st.code(r['masked_email'])
        for f in r['findings']:
            with st.expander(f"{f['category']} | {f['confidence']:.0%}",expanded=True):
                st.write(f['reason'])
                for e in f['evidence']:st.info(f"Line {e['line_number']}: {e['text']}\n\n{e['rationale']}")
                for p in f.get('policy_basis',[]):st.caption(f"{p['source']} | {p['section']}");st.code(p['text'][:500])
        st.write('Agent trace',r['agent_trace']);st.json(r['score_breakdown']);st.download_button('Download masked result',json.dumps(r,indent=2),mid+'.json')
elif page=='Alerts':st.dataframe(get('/alerts'),use_container_width=True)
elif page=='Matrix':
    m=get('/matrix');minimum=st.number_input('Minimum score',0.,100.,float(m['minimum_flag_score']));cats={k:{**v,'weight':st.slider(k,0,100,int(v['weight']))} for k,v in m['categories'].items()}
    if st.button('Save matrix'):m['minimum_flag_score']=minimum;m['categories']=cats;r=httpx.put(API+'/matrix',json=m,headers={'X-Admin-Key':key});st.success(r.json()) if r.is_success else st.error(r.text)
else:
    up=st.file_uploader('Approved policy',type=['md','txt'])
    if up and st.button('Upload'):r=httpx.post(API+'/policies',json={'filename':up.name,'content':up.getvalue().decode('utf-8',errors='ignore')},headers={'X-Admin-Key':key},timeout=120);st.success(r.json()) if r.is_success else st.error(r.text)
    st.json(get('/policies'))
