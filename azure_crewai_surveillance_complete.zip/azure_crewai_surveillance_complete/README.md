# Azure CrewAI Communication Surveillance, complete native Windows project

## Requirements
- 64-bit Python 3.12
- Microsoft Visual C++ 2015-2022 Redistributable x64
- Azure OpenAI endpoint, key, API version and chat deployment name

## Install
```powershell
Set-Location "<extracted-project-folder>"
Set-ExecutionPolicy -Scope Process Bypass
.\setup_windows.ps1
```
The corrected compatible NLP set is NumPy 2.0.2, Thinc 8.3.6 and spaCy 3.8.7.

## Configure
```powershell
Copy-Item .env.example .env
notepad .env
```
Fill the Azure OpenAI values. Keep `ADMIN_API_KEY=local-development-key` for local development.

## Start
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start_windows.ps1
```
Dashboard: http://localhost:8501
API docs: http://127.0.0.1:8000/docs
Health: http://127.0.0.1:8000/health

## Processing flow
Guardrails -> Presidio/spaCy PII masking -> deterministic rules -> local policy RAG -> Azure OpenAI CrewAI analyst -> verifier -> validated evidence and policy support -> deterministic score -> human review.

Use synthetic data until enterprise identity, encryption, private networking, DLP, retention, audit, database and model-risk controls are approved.
