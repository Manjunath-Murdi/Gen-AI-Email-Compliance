﻿$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$info=py -3.12 -c "import sys,struct;print(sys.version.split()[0]);print(struct.calcsize('P')*8)"
if($LASTEXITCODE -ne 0 -or $info[-1] -ne '64'){throw 'Install 64-bit Python 3.12 first.'}
if(Test-Path .venv){Remove-Item -Recurse -Force .venv}
py -3.12 -m venv .venv
$py='.\.venv\Scripts\python.exe'
& $py -m pip install --upgrade pip setuptools wheel
if($LASTEXITCODE -ne 0){throw 'pip tooling upgrade failed.'}
& $py -m pip install --no-cache-dir --only-binary=:all: numpy==2.0.2 thinc==8.3.6 spacy==3.8.7 click==8.1.8
if($LASTEXITCODE -ne 0){throw 'Compatible NLP packages could not be installed.'}
& $py -c "import numpy,thinc,spacy;print('NumPy',numpy.__version__);print('Thinc',thinc.__version__);print('spaCy',spacy.__version__);print('NLP BINARY STACK PASS')"
if($LASTEXITCODE -ne 0){throw 'NLP native import failed. Repair Microsoft Visual C++ 2015-2022 x64 Runtime, reboot, and rerun.'}
& $py -m pip install --no-cache-dir -r requirements.txt
if($LASTEXITCODE -ne 0){throw 'Application dependency installation failed.'}
& $py -m spacy download en_core_web_sm
if($LASTEXITCODE -ne 0){throw 'spaCy model download failed.'}
& $py -c "import spacy;spacy.load('en_core_web_sm');from presidio_analyzer import AnalyzerEngine;AnalyzerEngine();print('spaCy + Presidio PASS')"
if($LASTEXITCODE -ne 0){throw 'spaCy model or Presidio initialization failed.'}
& $py -m pip check
if($LASTEXITCODE -ne 0){throw 'Broken dependencies detected.'}
& $py -m pytest -q
if($LASTEXITCODE -ne 0){throw 'Tests failed.'}
Write-Host 'INSTALLATION PASS. Configure .env then run start_windows.ps1' -ForegroundColor Green

