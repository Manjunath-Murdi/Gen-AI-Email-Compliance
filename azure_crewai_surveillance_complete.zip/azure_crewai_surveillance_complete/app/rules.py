import re
RULES={'secrecy':r'keep this between us|delete (this|the) (email|message)|personal email|off.channel','market_manipulation_misconduct':r'(push|move|support) the (closing )?price|wash trade|spoof|front.run|inside information','market_bribery':r'kickback|quid pro quo|under the table|cash payment','complaints':r'formal complaint|whistleblow|harassment|retaliation','employee_ethics':r'conflict of interest|backdate|falsify|misrepresent|bypass the policy'}
def analyze(text):
    out=[]
    for cat,pat in RULES.items():
        ev=[{'line_number':n,'text':line.strip(),'rationale':'Deterministic compliance indicator'} for n,line in enumerate(text.splitlines(),1) if re.search(pat,line,re.I)]
        if ev: out.append({'category':cat,'confidence':.9,'reason':'Potential '+cat.replace('_',' '),'evidence':ev,'policy_basis':[]})
    return out
