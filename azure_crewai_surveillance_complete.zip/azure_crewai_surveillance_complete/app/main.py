import yaml
from pathlib import Path
from fastapi import FastAPI,HTTPException,Header,Depends
from fastapi.middleware.cors import CORSMiddleware
from .models import EmailInput,MatrixUpdate,PolicyUpload
from .settings import settings
from .privacy import PrivacyService
from .guardrails import inspect
from .rules import analyze
from .rag import PolicyRAG
from .agents import ComplianceCrew
from .store import init,save,history
BASE=Path(__file__).resolve().parent.parent; MP=BASE/'config'/'risk_matrix.yaml'; rag=PolicyRAG(); privacy=PrivacyService(); init(); s=settings(); app=FastAPI(title='Azure CrewAI Surveillance',version='6.0')
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in s.cors_origins.split(',')],allow_methods=['GET','POST','PUT'],allow_headers=['Content-Type','X-Admin-Key'])
def matrix():return yaml.safe_load(MP.read_text(encoding='utf-8'))
def admin(x_admin_key:str=Header(default='')):
    if x_admin_key!=s.admin_api_key:raise HTTPException(403,'Admin authorization failed')
@app.get('/health')
def health():return {'status':'ok','llm_enabled':s.llm_configured,'rag':rag.reindex(),'pii_engine':'presidio-spacy'}
@app.post('/analyze')
def run(e:EmailInput):
    numbered='\n'.join(f'{i}: {x}' for i,x in enumerate(e.body.splitlines() or [e.body],1)); flags=inspect(e.body); masked,entities,engine=privacy.protect(numbered); rules=analyze(masked); policies=rag.retrieve(e.subject+' '+masked,s.rag_top_k)
    findings,trace=(rules,['Secret guardrail blocked Azure OpenAI']) if 'SECRET_DETECTED' in flags else ComplianceCrew().run(masked,rules,policies)
    m=matrix(); findings=[f for f in findings if f.get('category') in m['categories']]
    if findings:
        cr=max(m['categories'][f['category']]['weight']*f['confidence'] for f in findings)*.8; cf=max(f['confidence'] for f in findings)*m['confidence_weight']; b=(m['bonuses']['multiple_categories'] if len(findings)>1 else 0)+(m['bonuses']['pii_present'] if entities else 0)+(m['bonuses']['policy_support'] if any(f.get('policy_basis') for f in findings) else 0)
        if any(r.rsplit('@',1)[-1].lower()!=e.sender.rsplit('@',1)[-1].lower() for r in e.recipients):b+=m['bonuses']['external_party']
    else:cr=cf=b=0
    score=min(100,cr+cf+b); p=m['priority']; priority='critical' if score>=p['critical'] else 'high' if score>=p['high'] else 'medium' if score>=p['medium'] else 'low'
    result={'message_id':e.message_id,'flagged':bool(findings) and score>=m['minimum_flag_score'],'priority':priority,'risk_score':round(score,2),'findings':findings,'pii_entities':entities,'pii_engine':engine,'masked_email':masked,'guardrail_flags':flags,'retrieved_policies':policies,'score_breakdown':{'category_risk':round(cr,2),'confidence':round(cf,2),'bonuses':round(b,2)},'agent_trace':trace,'requires_human_review':True}
    save(result);return result
@app.get('/alerts')
def alerts():return history()
@app.get('/matrix')
def get_matrix():return matrix()
@app.put('/matrix')
def set_matrix(x:MatrixUpdate,_=Depends(admin)):
    d=x.model_dump(); p=d['priority']
    if not p['critical']>=p['high']>=p['medium']>=p['low']:raise HTTPException(400,'Threshold order invalid')
    d['version']=matrix()['version']+1;MP.write_text(yaml.safe_dump(d,sort_keys=False),encoding='utf-8');return d
@app.get('/policies')
def policies():return {'items':rag.chunks,'count':len(rag.chunks)}
@app.post('/policies')
def add_policy(x:PolicyUpload,_=Depends(admin)):return rag.save(x.filename,x.content)
