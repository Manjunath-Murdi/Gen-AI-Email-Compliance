from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer
from presidio_anonymizer import AnonymizerEngine
class PrivacyService:
    def __init__(self):
        self.analyzer=AnalyzerEngine()
        custom=[('IN_PAN',r'\b[A-Z]{5}\d{4}[A-Z]\b',.85),('IN_AADHAAR',r'(?<!\d)\d{4}[ -]?\d{4}[ -]?\d{4}(?!\d)',.8),('IN_PHONE',r'(?<!\d)(?:\+?91[- ]?)?[6-9]\d{9}(?!\d)',.8)]
        for name,regex,score in custom:
            self.analyzer.registry.add_recognizer(PatternRecognizer(supported_entity=name,patterns=[Pattern(name=name,regex=regex,score=score)]))
        self.anonymizer=AnonymizerEngine()
    def protect(self,text):
        hits=self.analyzer.analyze(text=text,language='en')
        return self.anonymizer.anonymize(text=text,analyzer_results=hits).text, sorted({x.entity_type for x in hits}), 'presidio-spacy'
