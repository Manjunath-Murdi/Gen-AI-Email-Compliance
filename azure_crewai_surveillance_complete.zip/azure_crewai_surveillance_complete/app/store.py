import sqlite3,json
from pathlib import Path
DB=Path(__file__).resolve().parent.parent/'data'/'alerts.db'
def init():
    with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY,message_id TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,priority TEXT,score REAL,flagged INT,result TEXT)')
def save(x):
    with sqlite3.connect(DB) as c:c.execute('INSERT INTO alerts(message_id,priority,score,flagged,result) VALUES(?,?,?,?,?)',(x['message_id'],x['priority'],x['risk_score'],int(x['flagged']),json.dumps(x)))
def history():
    with sqlite3.connect(DB) as c:
        c.row_factory=sqlite3.Row; return [dict(x) for x in c.execute('SELECT id,message_id,created_at,priority,score,flagged FROM alerts ORDER BY id DESC LIMIT 200')]
