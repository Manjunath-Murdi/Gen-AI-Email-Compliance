import re,hashlib
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
BASE=Path(__file__).resolve().parent.parent; DIR=BASE/'data'/'policies'
class PolicyRAG:
    def __init__(self): self.reindex()
    def reindex(self):
        DIR.mkdir(parents=True,exist_ok=True); self.chunks=[]
        for p in sorted(DIR.glob('*')):
            if p.suffix.lower() not in {'.md','.txt'}: continue
            for sec in re.split(r'(?=^##\s+)',p.read_text(encoding='utf-8',errors='ignore'),flags=re.M):
                sec=sec.strip()
                if sec:
                    cid=hashlib.sha256((p.name+sec).encode()).hexdigest()[:24]
                    self.chunks.append({'chunk_id':cid,'source':p.name,'section':sec.splitlines()[0].lstrip('# '),'text':sec})
        self.v=TfidfVectorizer(stop_words='english',ngram_range=(1,2)); self.m=self.v.fit_transform([x['text'] for x in self.chunks]) if self.chunks else None
        return {'documents':len(list(DIR.glob('*'))),'chunks':len(self.chunks)}
    def retrieve(self,q,k=5):
        if self.m is None:return []
        s=cosine_similarity(self.v.transform([q]),self.m).ravel(); idx=s.argsort()[::-1][:k]
        return [{**self.chunks[i],'score':round(float(s[i]),4)} for i in idx if s[i]>.03]
    def save(self,name,content):
        name=re.sub(r'[^A-Za-z0-9_.-]','_',Path(name).name)
        if not name.lower().endswith(('.md','.txt')): raise ValueError('Only .md/.txt allowed')
        (DIR/name).write_text(content,encoding='utf-8'); return self.reindex()
