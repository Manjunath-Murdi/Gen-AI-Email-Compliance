from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: str = "development"
    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment: str = ""
    admin_api_key: str = "local-development-key"
    rag_top_k: int = 5
    cors_origins: str = "http://localhost:8501"

    @property
    def llm_configured(self) -> bool:
        endpoint = self.azure_openai_endpoint.strip()
        key = self.azure_openai_api_key.strip()
        deployment = self.azure_openai_deployment.strip()
        invalid = {"", "replace-me", "YOUR-ACTUAL-AZURE-OPENAI-KEY", "YOUR-CHAT-DEPLOYMENT-NAME"}
        return endpoint not in invalid and key not in invalid and deployment not in invalid

@lru_cache
def settings() -> Settings:
    return Settings()