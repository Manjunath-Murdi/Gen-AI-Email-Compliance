import re
def inspect(text):
    flags=[]
    if re.search(r'ignore .*?(previous|system) instructions|reveal .*?system prompt|bypass .*?guardrail',text,re.I): flags.append('PROMPT_INJECTION_ATTEMPT')
    if re.search(r'BEGIN .*?PRIVATE KEY|\b(?:api[_-]?key|password|secret|token)\s*[:=]\s*\S+',text,re.I): flags.append('SECRET_DETECTED')
    return flags
