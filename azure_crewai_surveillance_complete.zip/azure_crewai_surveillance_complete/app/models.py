from pydantic import BaseModel, Field
from typing import Any
class EmailInput(BaseModel):
    message_id:str; sender:str; recipients:list[str]; subject:str=''; body:str=Field(min_length=1,max_length=20000)
class MatrixUpdate(BaseModel):
    version:int; minimum_flag_score:float; priority:dict[str,float]; confidence_weight:float; bonuses:dict[str,float]; categories:dict[str,dict[str,Any]]
class PolicyUpload(BaseModel):
    filename:str; content:str=Field(min_length=1,max_length=200000)
