$ErrorActionPreference='Stop';Set-Location $PSScriptRoot
if(!(Test-Path .env)){Copy-Item .env.example .env;Write-Host 'Created .env. Fill Azure values, then rerun.' -ForegroundColor Yellow;exit 1}
$py=(Resolve-Path '.\.venv\Scripts\python.exe').Path
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot'; & '$py' -m uvicorn app.main:app --reload"
Start-Sleep -Seconds 5
& $py -m streamlit run dashboard.py
