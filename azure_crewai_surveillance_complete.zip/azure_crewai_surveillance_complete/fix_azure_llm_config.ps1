$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$envFile = Join-Path $PSScriptRoot '.env'
$settingsFile = Join-Path $PSScriptRoot 'app\settings.py'
$pythonExe = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'

if (!(Test-Path $pythonExe)) { throw '.venv Python was not found.' }
if (!(Test-Path $envFile)) { Copy-Item '.env.example' '.env'; throw '.env was created. Fill the Azure values and rerun this script.' }
if (!(Test-Path $settingsFile)) { throw 'app\settings.py was not found.' }

# Normalize .env to UTF-8 without BOM and remove accidental spaces around keys.
$lines = Get-Content $envFile
$normalized = foreach ($line in $lines) {
    if ($line -match '^\s*#' -or [string]::IsNullOrWhiteSpace($line)) { $line }
    elseif ($line -match '^\s*([^=]+?)\s*=\s*(.*)\s*$') { "$($matches[1].Trim())=$($matches[2].Trim().Trim('"').Trim("'"))" }
    else { $line }
}
[System.IO.File]::WriteAllLines($envFile, $normalized, [System.Text.UTF8Encoding]::new($false))

# Make settings load .env from the project root regardless of the launch directory.
$settings = @'
from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: str = "development"
    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment: str = ""
    admin_api_key: str = "local-development-key"
    rag_top_k: int = 5
    cors_origins: str = "http://localhost:8501"

    @property
    def llm_configured(self) -> bool:
        endpoint = self.azure_openai_endpoint.strip()
        key = self.azure_openai_api_key.strip()
        deployment = self.azure_openai_deployment.strip()
        invalid = {"", "replace-me", "YOUR-ACTUAL-AZURE-OPENAI-KEY", "YOUR-CHAT-DEPLOYMENT-NAME"}
        return endpoint not in invalid and key not in invalid and deployment not in invalid

@lru_cache
def settings() -> Settings:
    return Settings()
'@
[System.IO.File]::WriteAllText($settingsFile, $settings, [System.Text.UTF8Encoding]::new($false))

Write-Host 'Checking resolved configuration without printing the secret...' -ForegroundColor Cyan
& $pythonExe -c "from app.settings import settings, ENV_FILE; s=settings(); print('ENV_FILE:', ENV_FILE); print('ENV exists:', ENV_FILE.exists()); print('Endpoint:', s.azure_openai_endpoint); print('Key length:', len(s.azure_openai_api_key)); print('Deployment:', s.azure_openai_deployment); print('API version:', s.azure_openai_api_version); print('LLM configured:', s.llm_configured)"
if ($LASTEXITCODE -ne 0) { throw 'Settings validation failed.' }

$configured = & $pythonExe -c "from app.settings import settings; print('true' if settings().llm_configured else 'false')"
if ($configured.Trim() -ne 'true') {
    throw 'Azure OpenAI values are still placeholders or blank. Edit .env, then rerun this script.'
}

# Stop stale listener on port 8000 so the restarted API loads the corrected settings.
$connections = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
if ($connections) {
    $connections | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object {
        Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 2
}

Write-Host 'Configuration repaired. Start FastAPI with:' -ForegroundColor Green
Write-Host '.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000' -ForegroundColor Yellow
