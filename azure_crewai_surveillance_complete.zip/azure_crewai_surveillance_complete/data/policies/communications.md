# Communications and Records Policy
## RC-2.1 Record retention
Employees must not delete, destroy, conceal, or request deletion of regulated business communications.
## RC-2.2 Approved channels
Business communications must use approved systems. Moving business discussions off-channel to avoid monitoring is prohibited.
