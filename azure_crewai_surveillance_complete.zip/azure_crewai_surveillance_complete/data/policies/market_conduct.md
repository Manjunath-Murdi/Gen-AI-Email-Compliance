# Market Conduct Policy
## MC-4.1 Price integrity
Employees must not coordinate or request activity intended to create an artificial price, misleading closing price, false market appearance, or improper benchmark outcome.
## MC-4.2 Prohibited practices
Spoofing, layering, wash trading, front-running, and misuse of inside information are prohibited.
