# Ethics and Anti-Bribery Policy
## EA-3.1 Improper benefits
Employees must not offer, request, authorize, or accept cash, kickbacks, favors, gifts, or hospitality in exchange for an improper business or market outcome.
## EA-3.2 Complaints
Complaints, whistleblower reports, harassment allegations, and retaliation concerns must be preserved and reviewed independently.
